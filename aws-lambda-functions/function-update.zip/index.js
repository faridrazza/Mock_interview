const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

/**
 * AWS Lambda function for speech-to-text conversion using Amazon Transcribe
 * Fixed version with improved codec compatibility and error handling
 * 
 * This function provides:
 * - Real-time speech-to-text with Amazon Transcribe
 * - WebM to WAV conversion for better compatibility
 * - Robust error handling and logging
 * - Cost-effective AWS-native solution
 */

// Initialize AWS services
const transcribe = new AWS.TranscribeService({
  region: process.env.AWS_REGION || 'us-east-1'
});

const s3 = new AWS.S3({
  region: process.env.AWS_REGION || 'us-east-1'
});

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

// S3 bucket for temporary audio storage
const TEMP_BUCKET = process.env.TEMP_AUDIO_BUCKET;

/**
 * Simplified base64 processing (removed complex chunking)
 * @param {string} base64String - Base64 encoded audio data
 * @returns {Buffer} - Audio buffer
 */
function processBase64Audio(base64String) {
  try {
    if (!base64String || typeof base64String !== 'string') {
      throw new Error('Invalid base64 string provided');
    }
    
    // Clean the base64 string (remove data URL prefix if present)
    let cleanBase64 = base64String;
    if (base64String.includes(',')) {
      cleanBase64 = base64String.split(',')[1];
    }
    
    // Remove whitespace
    cleanBase64 = cleanBase64.replace(/\s/g, '');
    
    // Add padding if necessary
    while (cleanBase64.length % 4 !== 0) {
      cleanBase64 += '=';
    }
    
    // Direct conversion to buffer (much simpler and more reliable)
    const audioBuffer = Buffer.from(cleanBase64, 'base64');
    
    if (audioBuffer.length === 0) {
      throw new Error('Processed audio data is empty');
    }
    
    return audioBuffer;
  } catch (error) {
    console.error('Base64 processing error:', error);
    throw new Error(`Failed to process audio data: ${error.message}`);
  }
}

/**
 * Upload audio to S3 for Transcribe processing
 * @param {Buffer} audioBuffer - Audio data
 * @param {string} key - S3 object key
 * @returns {Promise<string>} - S3 URI
 */
async function uploadAudioToS3(audioBuffer, key) {
  try {
    if (!TEMP_BUCKET) {
      throw new Error('TEMP_AUDIO_BUCKET environment variable is not configured');
    }
    
    const params = {
      Bucket: TEMP_BUCKET,
      Key: key,
      Body: audioBuffer,
      ContentType: 'audio/wav', // Use WAV for better compatibility
      Expires: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
    };

    await s3.upload(params).promise();
    console.log(`Audio uploaded to S3: ${key} (${audioBuffer.length} bytes)`);
    return `s3://${TEMP_BUCKET}/${key}`;
  } catch (error) {
    console.error('S3 upload failed:', error);
    throw new Error(`S3 upload failed: ${error.message}`);
  }
}

/**
 * Start transcription job with Amazon Transcribe
 * @param {string} audioUri - S3 URI of audio file
 * @param {string} jobName - Unique job name
 * @returns {Promise<string>} - Job name
 */
async function startTranscriptionJob(audioUri, jobName) {
  try {
    const params = {
      TranscriptionJobName: jobName,
      Media: {
        MediaFileUri: audioUri
      },
      MediaFormat: 'wav', // Use WAV format for better compatibility
      LanguageCode: 'en-US',
      OutputBucketName: TEMP_BUCKET,
      Settings: {
        MaxSpeakerLabels: 1,
        ShowSpeakerLabels: false,
        MaxAlternatives: 1
      }
    };

    const result = await transcribe.startTranscriptionJob(params).promise();
    console.log(`Transcription job started: ${jobName}`);
    return jobName;
  } catch (error) {
    console.error('Failed to start transcription job:', error);
    throw new Error(`Transcription job start failed: ${error.message}`);
  }
}

/**
 * Wait for transcription job to complete and get results
 * @param {string} jobName - Transcription job name
 * @returns {Promise<string>} - Transcribed text
 */
async function waitForTranscriptionResult(jobName) {
  let attempts = 0;
  const maxAttempts = 30; // 30 seconds max wait
  
  while (attempts < maxAttempts) {
    try {
      const result = await transcribe.getTranscriptionJob({
        TranscriptionJobName: jobName
      }).promise();
      
      const status = result.TranscriptionJob.TranscriptionJobStatus;
      console.log(`Transcription job ${jobName} status: ${status}`);
      
      if (status === 'COMPLETED') {
        const transcriptUri = result.TranscriptionJob.Transcript.TranscriptFileUri;
        const s3Key = transcriptUri.split('/').pop();
        
        const transcriptData = await s3.getObject({
          Bucket: TEMP_BUCKET,
          Key: s3Key
        }).promise();
        
        const transcript = JSON.parse(transcriptData.Body.toString());
        
        // Clean up temporary files
        await cleanupTempFiles(jobName, s3Key);
        
        const transcribedText = transcript.results.transcripts[0]?.transcript || '';
        
        if (!transcribedText.trim()) {
          throw new Error('No speech detected in audio recording');
        }
        
        return transcribedText;
        
      } else if (status === 'FAILED') {
        const failureReason = result.TranscriptionJob.FailureReason || 'Unknown failure';
        console.error(`Transcription job failed: ${failureReason}`);
        
        // Provide specific error messages based on common failure reasons
        if (failureReason.includes('audio format')) {
          throw new Error('Audio format not supported. Please try recording again.');
        } else if (failureReason.includes('too short')) {
          throw new Error('Audio recording is too short. Please speak for at least 2 seconds.');
        } else if (failureReason.includes('no speech')) {
          throw new Error('No speech detected. Please ensure you are speaking clearly into the microphone.');
        } else {
          throw new Error(`Transcription failed: ${failureReason}`);
        }
      }
      
      // Job is still in progress, wait and retry
      await new Promise(resolve => setTimeout(resolve, 1000));
      attempts++;
      
    } catch (error) {
      // If it's a known error from above, re-throw it
      if (error.message.includes('Transcription failed') || 
          error.message.includes('Audio format') || 
          error.message.includes('too short') ||
          error.message.includes('No speech detected')) {
        throw error;
      }
      
      // For other errors (like job not ready), continue waiting
      if (error.code === 'BadRequestException' || error.code === 'NotFoundException') {
        await new Promise(resolve => setTimeout(resolve, 1000));
        attempts++;
        continue;
      }
      
      console.error('Error checking transcription job:', error);
      throw new Error(`Error checking transcription status: ${error.message}`);
    }
  }
  
  throw new Error('Transcription job timed out. Please try with a shorter audio recording.');
}

/**
 * Clean up temporary S3 files
 * @param {string} jobName - Job name for audio file cleanup
 * @param {string} transcriptKey - Transcript file S3 key
 */
async function cleanupTempFiles(jobName, transcriptKey) {
  try {
    // Delete audio file
    await s3.deleteObject({
      Bucket: TEMP_BUCKET,
      Key: `${jobName}.wav`
    }).promise();
    
    // Delete transcript file
    await s3.deleteObject({
      Bucket: TEMP_BUCKET,
      Key: transcriptKey
    }).promise();
    
    console.log('Temporary files cleaned up successfully');
  } catch (error) {
    console.warn('Failed to clean up temporary files:', error.message);
    // Don't throw error for cleanup failures
  }
}

exports.handler = async (event) => {
  console.log('Amazon Transcribe speech-to-text request received');
  
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: 'ok'
    };
  }

  try {
    // Validate environment variables
    if (!process.env.TEMP_AUDIO_BUCKET) {
      console.error('TEMP_AUDIO_BUCKET environment variable is not set');
      return {
        statusCode: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'Server configuration error: TEMP_AUDIO_BUCKET not configured',
          provider: 'aws-transcribe',
          timestamp: new Date().toISOString()
        })
      };
    }

    // Test S3 bucket access
    try {
      await s3.headBucket({ Bucket: process.env.TEMP_AUDIO_BUCKET }).promise();
      console.log('S3 bucket access confirmed');
    } catch (s3Error) {
      console.error('S3 bucket access failed:', s3Error);
      return {
        statusCode: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: `S3 bucket access failed: ${s3Error.message}`,
          provider: 'aws-transcribe',
          timestamp: new Date().toISOString()
        })
      };
    }

    // Parse request body
    let body;
    try {
      if (!event.body) {
        throw new Error('No request body provided');
      }
      
      let rawBody = event.body;
      if (event.isBase64Encoded) {
        rawBody = Buffer.from(rawBody, 'base64').toString('utf-8');
      }
      
      body = JSON.parse(rawBody);
    } catch (parseError) {
      console.error('Failed to parse request body:', parseError);
      return {
        statusCode: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'Invalid JSON in request body',
          details: parseError.message,
          provider: 'aws-transcribe'
        })
      };
    }
    
    const { audio } = body;
    
    if (!audio || typeof audio !== 'string') {
      return {
        statusCode: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'Audio data must be provided as a base64 string',
          provider: 'aws-transcribe'
        })
      };
    }

    console.log(`Processing audio data (${audio.length} characters)`);

    // Process audio with simplified approach
    const binaryAudio = processBase64Audio(audio);
    console.log(`Audio buffer size: ${binaryAudio.length} bytes`);
    
    // Validate audio size (minimum 1KB, maximum 100MB)
    if (binaryAudio.length < 1024) {
      return {
        statusCode: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'Audio recording is too short. Please record for at least 2 seconds.',
          provider: 'aws-transcribe'
        })
      };
    }
    
    if (binaryAudio.length > 100 * 1024 * 1024) { // 100MB limit
      return {
        statusCode: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'Audio recording is too large. Please record a shorter message.',
          provider: 'aws-transcribe'
        })
      };
    }
    
    // Generate unique job identifiers
    const jobName = `transcribe-${uuidv4()}`;
    const audioKey = `${jobName}.wav`; // Use .wav extension for better compatibility
    
    // Upload audio to S3
    console.log('Uploading audio to S3...');
    const audioUri = await uploadAudioToS3(binaryAudio, audioKey);
    
    // Start transcription job
    console.log('Starting Amazon Transcribe job...');
    await startTranscriptionJob(audioUri, jobName);
    
    // Wait for transcription to complete
    console.log('Waiting for transcription to complete...');
    const transcribedText = await waitForTranscriptionResult(jobName);
    
    console.log(`Transcription completed: "${transcribedText}"`);
    
    // Clean up temporary audio file
    try {
      await s3.deleteObject({
        Bucket: process.env.TEMP_AUDIO_BUCKET,
        Key: audioKey
      }).promise();
      console.log('Temporary audio file cleaned up');
    } catch (cleanupError) {
      console.warn('Failed to clean up temporary file:', cleanupError.message);
    }

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        text: transcribedText,
        provider: 'aws-transcribe',
        jobName: jobName
      })
    };

  } catch (error) {
    console.error('Error in Amazon Transcribe speech-to-text:', error);
    
    // Provide user-friendly error messages
    let userMessage = error.message;
    let statusCode = 500;
    
    if (error.message.includes('Audio format') || 
        error.message.includes('too short') ||
        error.message.includes('No speech detected') ||
        error.message.includes('too large')) {
      statusCode = 400;
    }
    
    const errorResponse = {
      error: userMessage,
      provider: 'aws-transcribe',
      timestamp: new Date().toISOString()
    };
    
    // Add AWS error details for debugging (in development)
    if (error.code) {
      errorResponse.awsErrorCode = error.code;
    }
    
    return {
      statusCode: statusCode,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify(errorResponse)
    };
  }
}; 